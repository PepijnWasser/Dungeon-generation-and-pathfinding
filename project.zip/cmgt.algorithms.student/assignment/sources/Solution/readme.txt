﻿Put all your solution files in this folder.
Make sure you maintain a clean structure, eg create folders such as Dungeon, Agent, Pathfinder, etc 
Or folders such as assignment1.1, assignment1.2, etc