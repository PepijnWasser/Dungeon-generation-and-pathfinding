﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;

class MyDungeonNodeGraph : NodeGraph
{
	protected Dungeon _dungeon;
	Dictionary<Room, Node> _roomNodeDictionary = new Dictionary<Room, Node>();
	Dictionary<Door, Node> _doorNodeDictionary = new Dictionary<Door, Node>();

	public MyDungeonNodeGraph(Dungeon pDungeon) : base((int)(pDungeon.size.Width * pDungeon.scale), (int)(pDungeon.size.Height * pDungeon.scale), (int)pDungeon.scale / 3)
	{
		Debug.Assert(pDungeon != null, "Please pass in a dungeon.");

		_dungeon = pDungeon;
	}

	protected override void generate()
	{
		foreach (Room room in _dungeon.rooms)
		{
			Node latestNode = new Node(getRoomCenter(room));
			nodes.Add(latestNode);
			_roomNodeDictionary.Add(room, latestNode);
		}
		//The getDoorCenter is a convenience method to calculate the screen space center of a door
		foreach (Door door in _dungeon.doors)
		{
			Node latestNode = new Node(getDoorCenter(door));
			nodes.Add(latestNode);
			_doorNodeDictionary.Add(door, latestNode);
		}

		CreateConnections();
	}

	private void CreateConnections()
	{
		//create a connection between the two rooms and the door...
		foreach (Room room in _dungeon.rooms)
		{
			foreach (Door door in _dungeon.doors)
			{
				bool betweenWidth = (door.location.X >= room.area.X && door.location.X < room.area.X + room.area.Width);
				bool betweenHeight = (door.location.Y >= room.area.Y && door.location.Y < room.area.Y + room.area.Height);
				if (betweenHeight && betweenWidth)
				{
					_doorNodeDictionary.TryGetValue(door, out Node doorNodeToAdd);
					_roomNodeDictionary.TryGetValue(room, out Node roomNodeToAdd);
					AddConnection(doorNodeToAdd, roomNodeToAdd);
				}

			}
		}
	}

	protected Point getRoomCenter(Room pRoom)
	{
		float centerX = ((pRoom.area.Left + pRoom.area.Right) / 2.0f) * _dungeon.scale;
		float centerY = ((pRoom.area.Top + pRoom.area.Bottom) / 2.0f) * _dungeon.scale;
		return new Point((int)centerX, (int)centerY);
	}

	protected Point getDoorCenter(Door pDoor)
	{
		return getPointCenter(pDoor.location);
	}

	protected Point getPointCenter(Point pLocation)
	{
		float centerX = (pLocation.X + 0.5f) * _dungeon.scale;
		float centerY = (pLocation.Y + 0.5f) * _dungeon.scale;
		return new Point((int)centerX, (int)centerY);
	}

}
