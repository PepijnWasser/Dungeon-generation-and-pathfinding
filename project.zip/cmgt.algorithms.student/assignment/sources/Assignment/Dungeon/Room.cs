﻿using System.Drawing;

/**
 * This class represents (the data for) a Room, at this moment only a rectangle in the dungeon.
 */
class Room 
{
	public Rectangle area;
	Dungeon _myDungeon;

	public Room (Rectangle pArea, Dungeon mydungeon)
	{
		_myDungeon = mydungeon;
		area = pArea;
	}

	public int GetNumberOfDoors()
	{
		int amountOfDoors = 0;
		foreach(Door _door in _myDungeon.doors)
		{
			if (_door.location.X >= this.area.X && _door.location.X <= this.area.X + this.area.Width &&	_door.location.Y >= this.area.Y && _door.location.Y <= this.area.Y + this.area.Height - 1)
			{
				amountOfDoors += 1;
			}
		}
		return amountOfDoors;
	}


	//TODO: Implement a toString method for debugging?
	//Return information about the type of object and it's data
	//eg Room: (x, y, width, height)

}
