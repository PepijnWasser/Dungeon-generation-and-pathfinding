﻿using GXPEngine;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Reflection.Emit;

class MyDungeon : Dungeon
{
	int worldSeed = 199;

	public MyDungeon(Size pSize, int gridSize) : base(pSize, gridSize) 
	{

	}

	protected override void generate(int pMinimumRoomSize)
	{
		rooms.Add(new Room(new Rectangle(0, 0, size.Width, size.Height), this));
		int roomsCleared = 0;

		while(roomsCleared < rooms.Count)
		{
			List<Room> _roomsToRemove = new List<Room>();
			List<Room> _roomsToAdd = new List<Room>();
			List<Door> _doorsToAdd = new List<Door>();

			foreach (Room _room in rooms)
			{
				roomsCleared = GetRoomsCount(pMinimumRoomSize, roomsCleared, _roomsToRemove, _roomsToAdd, _room);
			}
			AddAndRemoveRoomsFromList(_roomsToRemove, _roomsToAdd);
		}
	}

	private int GetRoomsCount(int pMinimumRoomSize, int roomsCleared, List<Room> _roomsToRemove, List<Room> _roomsToAdd, Room _room)
	{
		if (_room.area.Height >= 2 * pMinimumRoomSize)
		{
			roomsCleared = SplitRoomByHeight(pMinimumRoomSize, roomsCleared, _roomsToRemove, _roomsToAdd, _room);
		}
		else if (_room.area.Width >= 2 * pMinimumRoomSize)
		{
			roomsCleared = SplitRoomByWidth(pMinimumRoomSize, roomsCleared, _roomsToRemove, _roomsToAdd, _room);
		}
		else
		{
			roomsCleared += 1;
		}

		return roomsCleared;
	}

	private void AddAndRemoveRoomsFromList(List<Room> _roomsToRemove, List<Room> _roomsToAdd)
	{
		foreach (Room _room in _roomsToAdd)
		{
			rooms.Add(_room);
		}

		foreach (Room _room in _roomsToRemove)
		{
			rooms.Remove(_room);
		}
	}

	private int SplitRoomByHeight(int pMinimumRoomSize, int roomsCleared, List<Room> _roomsToRemove, List<Room> _roomsToAdd, Room _room)
	{
		int breakHeight = GetRandomValue(pMinimumRoomSize, _room.area.Height - pMinimumRoomSize + 1);
		int doorsCompleted = 0;

		List<int> wrongPositions = new List<int>();
		bool roomPossible = true;
		while (doorsCompleted < doors.Count && roomPossible == true)
		{
			doorsCompleted = 0;
			foreach (Door _door in doors)
			{
				SplitIfPossible(pMinimumRoomSize, ref roomsCleared, _room, ref breakHeight, ref doorsCompleted, wrongPositions, ref roomPossible, _door);
			}
		}
		if (roomPossible == true)
		{
			UpdateRoomsListByHeight(_roomsToAdd, _roomsToRemove, _room, breakHeight);
			AddDoorInVerticalWall(_room, breakHeight);
		}

		return roomsCleared;
	}

	private void UpdateRoomsListByHeight(List<Room> _roomsToAdd, List<Room> _roomsToRemove, Room _room, int breakHeight)
	{
		_roomsToAdd.Add(new Room(new Rectangle(_room.area.X, _room.area.Y, _room.area.Width, breakHeight + 1), this));
		_roomsToAdd.Add(new Room(new Rectangle(_room.area.X, _room.area.Y + breakHeight, _room.area.Width, _room.area.Height - breakHeight), this));
		_roomsToRemove.Add(_room);
	}

	private void AddDoorInVerticalWall(Room _room, int breakHeight)
	{
		int doorX = GetRandomValue(1, _room.area.Width - 1);
		doors.Add(new Door(new Point(_room.area.X + doorX, _room.area.Y + breakHeight)));
		
	}

	private void SplitIfPossible(int pMinimumRoomSize, ref int roomsCleared, Room _room, ref int breakHeight, ref int doorsCompleted, List<int> wrongPositions, ref bool roomPossible, Door _door)
	{
		if (_door.location.X == _room.area.X && _door.location.Y == _room.area.Y + breakHeight || _door.location.X == _room.area.X + _room.area.Width && _door.location.Y == _room.area.Y + breakHeight)
		{
			if (wrongPositions.Contains(breakHeight) == false)
			{
				wrongPositions.Add(breakHeight);
			}
			if (wrongPositions.Count == _room.area.Height - 2 * pMinimumRoomSize)
			{
				roomsCleared += 1;
				roomPossible = false;
			}
			breakHeight = GetRandomValue(pMinimumRoomSize, _room.area.Height - pMinimumRoomSize + 1);
		}
		else
		{
			doorsCompleted += 1;
		}
	}

	private int SplitRoomByWidth(int pMinimumRoomSize, int roomsCleared, List<Room> _roomsToRemove, List<Room> _roomsToAdd, Room _room)
	{
		int breakWidth = GetRandomValue(pMinimumRoomSize, _room.area.Width - pMinimumRoomSize + 1);
		int doorsCompleted = 0;

		List<int> wrongPositions = new List<int>();
		bool roomPossible = true;
		while (doorsCompleted < doors.Count && roomPossible == true)
		{
			doorsCompleted = 0;
			foreach (Door _door in doors)
			{
				if (_door.location.X == _room.area.X + breakWidth && _door.location.Y == _room.area.Y + _room.area.Height - 1 || _door.location.X == _room.area.X + breakWidth && _door.location.Y == _room.area.Y)
				{
					if (wrongPositions.Contains(breakWidth) == false)
					{
						wrongPositions.Add(breakWidth);
					}
					if (wrongPositions.Count == _room.area.Width - 2 * pMinimumRoomSize)
					{
						roomsCleared += 1;
						roomPossible = false;
					}
					breakWidth = GetRandomValue(pMinimumRoomSize, _room.area.Width - pMinimumRoomSize + 1);
				}
				else
				{
					doorsCompleted += 1;
				}
			}
		}
		if (roomPossible == true)
		{
			UpdateRoomsListByWidth(_roomsToRemove, _roomsToAdd, _room, breakWidth);
			AddDoorInHorizontalWall(_room, breakWidth);
		}

		return roomsCleared;
	}

	private void UpdateRoomsListByWidth(List<Room> _roomsToRemove, List<Room> _roomsToAdd, Room _room, int breakWidth)
	{
		_roomsToAdd.Add(new Room(new Rectangle(_room.area.X, _room.area.Y, breakWidth + 1, _room.area.Height), this));
		_roomsToAdd.Add(new Room(new Rectangle(_room.area.X + breakWidth, _room.area.Y, _room.area.Width - breakWidth, _room.area.Height), this));
		_roomsToRemove.Add(_room);
	}

	private void AddDoorInHorizontalWall(Room _room, int breakWidth)
	{
		int doorY = GetRandomValue(1, _room.area.Height - 1);
		doors.Add(new Door(new Point(_room.area.X + breakWidth, _room.area.Y + doorY)));
	}

	int GetRandomValue(int min, int max)
	{
		worldSeed = worldSeed + 1;
		Random randomValue = new Random(worldSeed);
		return randomValue.Next(min, max);
	}
}

