﻿using GXPEngine;
using System;
using System.Collections.Generic;

/**
 * Very simple example of a nodegraphagent that walks directly to the node you clicked on,
 * ignoring walls, connections etc.
 */
class MyNodeGraphAgent : NodeGraphAgent
{
	List<Node> _nodesToMoveTo = new List<Node>();
	Node _lastNodeMovedTo;
	NodeGraph _nodeGraph;

	public MyNodeGraphAgent(NodeGraph pNodeGraph) : base(pNodeGraph)
	{
		Initiate(pNodeGraph);

		//listen to nodeclicks
		pNodeGraph.OnNodeLeftClicked += OnNodeClickHandler;
	}

	private void Initiate(NodeGraph pNodeGraph)
	{
		SetOrigin(width / 2, height / 2);

		_nodeGraph = pNodeGraph;

		if (pNodeGraph.nodes.Count > 0)
		{
			int _randomStartingPoint = Utils.Random(0, pNodeGraph.nodes.Count);
			jumpToNode(pNodeGraph.nodes[_randomStartingPoint]);
			_lastNodeMovedTo = pNodeGraph.nodes[_randomStartingPoint];
		}
	}

	protected virtual void OnNodeClickHandler(Node pNode)
	{
		List<Node> _path = new List<Node>(_nodeGraph.FindPath(_lastNodeMovedTo, pNode));
		_nodesToMoveTo.Clear();
		foreach (Node _node in _path)
		{
			_nodesToMoveTo.Insert(0, _node);
		}

		foreach (Node _node in _path)
		{
			Console.WriteLine(_node.id + "i");
		}
	}

	protected override void Update()
	{
		//no target? Don't walk
		if (_nodesToMoveTo.Count == 0) return;

		//Move towards the target node, if we reached it, clear the target
		if (moveTowardsNode(_nodesToMoveTo[0]))
		{
			_lastNodeMovedTo = _nodesToMoveTo[0];
			_nodesToMoveTo.Remove(_nodesToMoveTo[0]);
		}
	}
}
