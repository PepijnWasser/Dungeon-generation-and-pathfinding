﻿using GXPEngine;
using System;
using System.Collections.Generic;

/**
 * An example of a PathFinder implementation which completes the process by rolling a die 
 * and just returning the straight-as-the-crow-flies path if you roll a 6 ;). 
 */
class MyRecursivePathfinder : PathFinder
{
	List<Node> _shortestPath = new List<Node>();
	NodeGraph _nodeGraph;
	Node _destination;
	Node _start;

	public MyRecursivePathfinder(NodeGraph pGraph) : base(pGraph)
	{
		_nodeGraph = pGraph;
	}

	protected override List<Node> generate(Node pFrom, Node pTo)
	{
		List<Node> _currentPath = new List<Node>();
		Reset(_currentPath);

		_start = pFrom;
		_destination = pTo;

		if (_start == _destination)
		{
			_shortestPath.Add(_start);
		}
		else
		{
			_currentPath.Add(_start);
			Checkchildren(_start, _currentPath);
		}
		return _shortestPath;
	}

	private void Reset(List<Node> _currentPath)
	{
		_shortestPath.Clear();
		_currentPath.Clear();
	}

	void Checkchildren(Node _parentNode, List<Node> currentPath)
	{
		List<Node> PathTillNow = new List<Node>(currentPath);
		List<Node> _connectionsToParent = new List<Node>();

		GetConnections(_parentNode, PathTillNow, _connectionsToParent);

		if (_connectionsToParent.Count != 0)
		{
			CheckConnections(PathTillNow, _connectionsToParent);
		}
	}

	private void CheckConnections(List<Node> PathTillNow, List<Node> _connectionsToParent)
	{
		foreach (Node _connection in _connectionsToParent)
		{
			List<Node> NodesToSend = new List<Node>(PathTillNow);
			NodesToSend.Add(_connection);
			if (_connection == _destination)
			{
				UpdatePath(NodesToSend);
			}
			else
			{
				Checkchildren(_connection, NodesToSend);
			}
		}
	}

	private void UpdatePath(List<Node> NodesToSend)
	{
		if (_shortestPath.Count == 0)
		{
			Console.WriteLine("new shortest path created");
			_shortestPath = NodesToSend;
		}
		else if (NodesToSend.Count < _shortestPath.Count)
		{
			Console.WriteLine("new shortest path created");
			_shortestPath = NodesToSend;
		}
	}

	private void GetConnections(Node _parentNode, List<Node> PathTillNow, List<Node> _connectionsToParent)
	{
		foreach (Node _node in _nodeGraph.nodes)
		{
			if (_node.connections.Contains(_parentNode) && PathTillNow.Contains(_node) == false)
			{
				_connectionsToParent.Add(_node);
			}
		}
	}
}

