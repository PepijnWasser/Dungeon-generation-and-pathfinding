﻿using GXPEngine;
using System;
using System.Collections.Generic;

/**
 * An example of a PathFinder implementation which completes the process by rolling a die 
 * and just returning the straight-as-the-crow-flies path if you roll a 6 ;). 
 */
class MyItterativePathfinder : PathFinder
{
	List<Node> _path;
	Node _destination;
	Node _start;

	Dictionary<Node, Node> _parentDictionary;
	List<Node> _NodesChecked;
	List<Node> _que;

	NodeGraph _nodeGraph;


	public MyItterativePathfinder(NodeGraph pGraph) : base(pGraph)
	{
		_nodeGraph = pGraph;
	}

	protected override List<Node> generate(Node pFrom, Node pTo)
	{
		_destination = pTo;
		_start = pFrom;
		Reset();

		if(_start == _destination)
		{
			_path.Add(_start);
		}
		else
		{
			_NodesChecked.Add(_start);
			AddNewNodesToQue(_start);
			MakePath();
			WriteDebugInfo();
		}
		return _path;

	}

	private void WriteDebugInfo()
	{
		Console.Clear();
		Console.WriteLine("there are " + _NodesChecked.Count + " nodes being checked and in que from the total amount of " + _nodeGraph.nodes.Count + " nodes");
		Console.WriteLine("the nodes are:");
		foreach (Node _node in _NodesChecked)
		{
			Console.WriteLine(_node.id);
		}
	}

	void MakePath()
	{
		if(_que.Count != 0)
		{
			if (_que[0] == _destination)
			{
				GeneratePath(_destination);
			}
			else
			{
				AddNewNodesToQue(_que[0]);
				_que.RemoveAt(0);
				MakePath();
			}
		}
		else
		{
			Console.WriteLine("something seems to be wrong. there are no items in que");
		}	
	}

	void AddNewNodesToQue(Node parentNode)
	{
		foreach (Node _node in _nodeGraph.nodes)
		{
			if (_node.connections.Contains(parentNode) && _NodesChecked.Contains(_node) == false)
			{
				_que.Add(_node);
				_NodesChecked.Add(_node);
				_parentDictionary.Add(_node, parentNode);
			}
		}
	}

	void GeneratePath(Node child)
	{
		_parentDictionary.TryGetValue(child, out Node parent);
		_path.Add(child);
		if (parent == _start)
		{
			_path.Add(parent);
		}
		else
		{
			GeneratePath(parent);
		}
	}

	void Reset()
	{
		_path = new List<Node>();
		_parentDictionary = new Dictionary<Node, Node>();
		_NodesChecked = new List<Node>();
		_que = new List<Node>();
	}
}

